/**
* MMU using random selection replacement strategy
*/

public class RandMMU implements MMU {
    public RandMMU(int frames) {
        //todo
    }
    
    public void setDebug() {
        //todo
    }
    
    public void resetDebug() {
        //todo
    }
    
    public void readMemory(int page_number) {
        //todo
    }
    
    public void writeMemory(int page_number) {
        //todo
    }
    
    public int getTotalDiskReads() {
        //todo
        return -1;
    }
    
    public int getTotalDiskWrites() {
        //todo
        return -1;
    }
    
    public int getTotalPageFaults() {
        return -1;
    }
}